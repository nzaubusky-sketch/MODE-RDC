# MODE RDC — Marketplace

Marketplace e-commerce RDC avec catalogue, panier, commandes, comptes client/vendeur/admin, RBAC serveur et paiements.

## Paiement

Le projet possède deux modes :

- `PAYMENT_PROVIDER=mock` : test local, aucune transaction réelle.
- `PAYMENT_PROVIDER=nexera` : utilise le SDK Nexera Pay. Le serveur conserve les secrets et initie le paiement Mobile Money. Les opérateurs prévus sont M-Pesa, Airtel Money, Orange Money et Africell.

Créer `.env` depuis `.env.example`, puis renseigner uniquement côté serveur :

```env
PAYMENT_PROVIDER=nexera
NEXERA_PAY_API_KEY=...
NEXERA_PAY_SECRET=...
PAYMENT_WEBHOOK_SECRET=...
PAYMENT_CALLBACK_URL=https://votre-domaine.cd/api/payments/webhook
```

Ne jamais mettre ces valeurs dans `public/index.html`.

## Installation

```bash
npm install
npm start
```

## Comptes de démonstration

Les comptes de seed sont uniquement destinés au développement. Changez/supprimez les identifiants avant toute mise en production.

## Sécurité production

- HTTPS obligatoire
- secrets uniquement dans l'environnement serveur / secret manager
- cookies HttpOnly + Secure + SameSite
- RBAC côté API, jamais uniquement dans l'interface
- prix et stock recalculés côté serveur
- webhook de paiement vérifié par signature
- idempotence des paiements
- rate limiting
- validation Zod
- logs d'audit
- sauvegardes chiffrées de la base
- rotation des secrets
