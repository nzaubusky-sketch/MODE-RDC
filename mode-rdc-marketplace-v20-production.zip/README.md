# MODE RDC V20 — Production readiness

Marketplace RDC full-stack : Node.js + Express + SQLite + interface HTML/CSS/JS.

## Sécurité
- Mots de passe hachés avec bcrypt
- Sessions JWT avec JTI + révocation serveur
- Cookies HttpOnly et Secure en production
- RBAC client / vendeur / administrateur
- Rate limiting HTTP et protection contre les tentatives de connexion répétées
- 2FA TOTP pour les administrateurs
- Journal d’audit et événements de sécurité
- Uploads privés hors du dossier public
- Validation serveur avec Zod
- Webhook de paiement vérifié par signature
- Aucun secret de paiement dans `public/`

## Fonctionnalités
- Catalogue, variantes, images et import/export CSV
- Recherche, filtres et recommandations
- Commandes, paiements, Mobile Money, remboursements et retraits
- Livraisons, livreurs, OTP et suivi
- Messagerie, support, retours et litiges
- Promotions et codes promo
- Avis et modération
- Notifications
- Finance et rapports périodiques avec exports CSV
- Paramètres généraux administrateur

## V20 — préparation production
- Correction du démarrage de l’interface (`siteSettings`)
- La devise configurée est transmise au flux de paiement au lieu d’être forcée à USD côté navigateur
- Endpoint de santé : `GET /api/health`
- Validation du port au démarrage
- Contrôle supplémentaire des secrets webhook en production avec un fournisseur de paiement réel
- Arrêt propre du serveur sur SIGINT/SIGTERM
- Suppression des fichiers de sauvegarde de développement de l’archive de livraison
- `.env`, bases SQLite et `node_modules` exclus du package

## Installation
1. Copier `.env.example` vers `.env`.
2. Définir une vraie valeur aléatoire pour `JWT_SECRET`.
3. En production, définir `NODE_ENV=production` et utiliser HTTPS.
4. Si un vrai fournisseur de paiement est activé, configurer ses clés uniquement dans `.env` ainsi que `PAYMENT_WEBHOOK_SECRET`.
5. Installer les dépendances : `npm install`.
6. Démarrer : `npm start`.
7. Vérifier `GET /api/health`.

## Important
Le fournisseur de paiement par défaut de l’archive reste `mock` pour les tests locaux. L’activation d’un paiement réel nécessite la configuration et la validation des identifiants du fournisseur choisi.
