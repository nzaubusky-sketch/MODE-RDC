# MODE RDC V16 — Recherche avancée & recommandations

V16 repart de V15 et ajoute une recherche serveur plus complète et des recommandations.

## Recherche
- recherche nom, description, catégorie et boutique
- catégorie
- prix min/max
- filtre stock disponible
- tri nouveautés, prix, notes, popularité
- pagination

## Recommandations
- historique des consultations pour utilisateurs connectés
- suggestions par catégories consultées
- fallback vers produits populaires/mieux notés

## Sécurité
- filtres et pagination traités côté serveur
- événements associés à l'utilisateur authentifié
- recommandations sans données sensibles

## Lancement
1. copier `.env.example` vers `.env`
2. définir un `JWT_SECRET` long et aléatoire
3. `npm install`
4. `npm start`
