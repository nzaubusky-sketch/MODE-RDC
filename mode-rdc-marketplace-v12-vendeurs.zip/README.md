# MODE RDC V12 — Gestion professionnelle des vendeurs

## Nouveautés
- Profil boutique enrichi : description, adresse, ville, site web, logo.
- Espace vendeur pour modifier les informations de boutique.
- Statistiques vendeur : produits, commandes payées et ventes.
- Documents KYC vendeur : identité, immatriculation, fiscalité, bancaire ou autre.
- Upload sécurisé des documents (JPG, PNG, WebP, PDF, 5 Mo max), stockage privé et accès autorisé.
- Dashboard admin de gestion des vendeurs avec recherche et filtres.
- Fiche détaillée vendeur : boutique, propriétaire, documents, produits et portefeuille.
- Validation, refus, suspension et remise en attente d'un vendeur.
- Validation/refus des documents avec note administrative.
- Notifications vendeur lors des décisions administratives.
- Audit des opérations sensibles.

## Sécurité
Les documents vendeurs ne sont pas servis depuis le dossier public. Leur accès passe par une route authentifiée et contrôlée selon le rôle et le propriétaire.

## Installation
1. Copier `.env.example` vers `.env`.
2. Définir `JWT_SECRET` avec une valeur longue et aléatoire.
3. Installer les dépendances : `npm install`.
4. Lancer : `npm start`.

Compte de démonstration initial : `seller@example.com` / `ChangeMe!123` (à changer avant production).
