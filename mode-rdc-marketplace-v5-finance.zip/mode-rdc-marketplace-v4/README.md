# MODE RDC Marketplace — V4

Marketplace full-stack pour la RDC, avec catalogue, panier, commandes, paiements, rôles et dashboards.

## Rôles
- **Client** : compte, catalogue, panier, commandes, paiement.
- **Vendeur** : boutique approuvée, ajout de produits, prix, stock, commandes et statuts.
- **Admin** : utilisateurs, vendeurs, produits, commandes, paiements et approbation des boutiques.

## Sécurité
- Authentification serveur avec bcrypt.
- Session JWT dans cookie HttpOnly/SameSite.
- RBAC appliqué sur les routes API.
- Validation Zod des données sensibles.
- Rate limiting et Helmet.
- Prix et stock recalculés côté serveur.
- Webhook paiement vérifié par HMAC.
- Secrets uniquement dans `.env`.
- Journal d'audit pour les actions sensibles.

## Paiement
Le mode par défaut est `mock`. Pour un prestataire réel, configurer les clés serveur et le secret webhook dans `.env`.

## Installation
```bash
npm install
cp .env.example .env
# remplacer JWT_SECRET par une valeur longue et aléatoire
npm start
```

Puis ouvrir `http://localhost:3000`.

Les comptes de démonstration et leurs mots de passe sont uniquement destinés au développement local et doivent être supprimés/changés avant production.

## Production
Utiliser HTTPS, une vraie base de données managée, sauvegardes, rotation des secrets, monitoring, vérification des webhooks du prestataire et suppression des comptes/mots de passe de démonstration.

## Finance marketplace (V5 module)

Added server-side seller finance management:
- configurable platform commission via `PLATFORM_COMMISSION_BPS` (default 1000 = 10%)
- seller wallet with available and pending balances
- automatic credit after a payment webhook changes an order to `paid`
- seller ledger for sales, commission and withdrawals
- seller withdrawal requests
- admin approval, rejection or marking a withdrawal as paid
- all financial mutations enforced server-side and audited

Example `.env`:
`PLATFORM_COMMISSION_BPS=1000`

Important: the wallet is an internal marketplace ledger. Actual money transfer to a seller still requires a real payout provider/integration and reconciliation process.
