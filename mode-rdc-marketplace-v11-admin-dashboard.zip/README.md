# MODE RDC V11 — Dashboard Admin professionnel

V11 enrichit MODE RDC avec un centre d'administration unifié :
- KPIs : CA payé, commissions, commandes, utilisateurs, vendeurs, produits, retraits et livraisons
- graphique des revenus des 30 derniers jours
- répartition des paiements et des statuts de commandes
- top vendeurs et alertes de stock faible
- accès rapide aux paiements, finance, livraisons, tickets, retours, litiges et remboursements
- gestion des utilisateurs et validation des vendeurs
- journal de sécurité/audit consultable par l'administrateur
- endpoints protégés par authentification + rôle admin

## Démarrage

1. `npm install`
2. Copier `.env.example` vers `.env`
3. Renseigner les secrets nécessaires
4. `npm start`
5. Ouvrir `http://localhost:3000`

Le projet ne contient pas `node_modules` ni de base de données de production.
