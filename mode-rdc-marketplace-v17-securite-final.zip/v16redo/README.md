# MODE RDC V17 — Sécurité avancée & antifraude

Base: V16 Recherche avancée & recommandations.

## Ajouts
- Sessions serveur révocables (JWT + jti + table user_sessions)
- Déconnexion avec révocation de session
- Liste et révocation des sessions utilisateur
- 2FA TOTP pour les comptes administrateur
- Écran de connexion avec champ de code 2FA
- Journal security_events
- Historique des tentatives de connexion
- Blocage temporaire après trop d'échecs depuis une même IP
- Centre de sécurité administrateur
- Audit des événements sensibles
- Les secrets 2FA restent côté serveur et ne sont jamais renvoyés après activation

## Variables
JWT_SECRET reste obligatoire dans `.env`.

## Installation
npm install
npm start
