import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Database from 'better-sqlite3';
import { z } from 'zod';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
const db=new Database(path.join(__dirname,'marketplace.db'));
const PORT=Number(process.env.PORT||3000);
const JWT_SECRET=process.env.JWT_SECRET;
if(!JWT_SECRET || JWT_SECRET==='CHANGE_ME_TO_A_LONG_RANDOM_SECRET') throw new Error('JWT_SECRET must be configured in .env');

db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('customer','seller','admin')),created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sellers(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER UNIQUE NOT NULL,shop TEXT NOT NULL,phone TEXT NOT NULL,category TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT NOT NULL,price_cents INTEGER NOT NULL,stock INTEGER NOT NULL DEFAULT 0,seller_id INTEGER NOT NULL,img TEXT,description TEXT,active INTEGER NOT NULL DEFAULT 1,FOREIGN KEY(seller_id) REFERENCES sellers(id));
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE NOT NULL,user_id INTEGER NOT NULL,total_cents INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'confirmed',payment_method TEXT NOT NULL,payment_status TEXT NOT NULL DEFAULT 'pending',shipping_name TEXT NOT NULL,shipping_phone TEXT NOT NULL,shipping_address TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,product_id INTEGER NOT NULL,quantity INTEGER NOT NULL,unit_price_cents INTEGER NOT NULL,FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,FOREIGN KEY(product_id) REFERENCES products(id));
CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,action TEXT NOT NULL,ip TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));
`);

const seed=()=>{
 const count=db.prepare('SELECT COUNT(*) c FROM users').get().c;if(count) return;
 const hash=bcrypt.hashSync('ChangeMe!123',12);
 const admin=db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)').run('Administrateur','admin@moder dc.local'.replace(' ',''),hash,'admin');
 const sellerUser=db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)').run('Maison Kin','seller@example.com',hash,'seller');
 const seller=db.prepare('INSERT INTO sellers(user_id,shop,phone,category,status) VALUES(?,?,?,?,?)').run(sellerUser.lastInsertRowid,'Maison Kin','+243000000000','Vêtements','approved');
 const products=[['Robe wax élégante','Vêtements',3500,20,'Robe inspirée des motifs africains.'],['Chemise homme classique','Vêtements',2500,30,'Chemise polyvalente.'],['Ensemble africain','Mode africaine',5500,15,'Ensemble aux inspirations africaines.']];
 const ins=db.prepare('INSERT INTO products(name,category,price_cents,stock,seller_id,description) VALUES(?,?,?,?,?,?)');products.forEach(p=>ins.run(p[0],p[1],p[2],p[3],seller.lastInsertRowid,p[4]));
};
seed();

app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'100kb'}));app.use(cookieParser());
app.use(rateLimit({windowMs:15*60*1000,max:300,standardHeaders:true,legacyHeaders:false}));
app.use(express.static(path.join(__dirname,'../public')));

function tokenFor(user){return jwt.sign({sub:user.id,role:user.role},JWT_SECRET,{expiresIn:'2h'});}
function auth(req,res,next){const token=req.cookies.session; if(!token) return res.status(401).json({error:'Authentification requise'});try{req.user=jwt.verify(token,JWT_SECRET);next()}catch{return res.status(401).json({error:'Session invalide ou expirée'})}}
function role(...roles){return (req,res,next)=>roles.includes(req.user.role)?next():res.status(403).json({error:'Accès refusé'});}
function audit(req,action){db.prepare('INSERT INTO audit_logs(user_id,action,ip) VALUES(?,?,?)').run(req.user?.sub||null,action,req.ip);}
const registerSchema=z.object({name:z.string().min(2).max(100),email:z.string().email().max(200),password:z.string().min(10).max(100)});

app.post('/api/auth/register',async(req,res)=>{try{const d=registerSchema.parse(req.body);const hash=await bcrypt.hash(d.password,12);const r=db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)').run(d.name,d.email.toLowerCase(),hash,'customer');const u={id:r.lastInsertRowid,role:'customer'};res.cookie('session',tokenFor(u),{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',maxAge:7200000});res.status(201).json({user:{id:u.id,name:d.name,email:d.email,role:u.role}})}catch(e){res.status(400).json({error:e.message.includes('UNIQUE')?'Email déjà utilisé':'Données invalides'})}});
app.post('/api/auth/login',async(req,res)=>{const {email,password}=req.body||{};const u=db.prepare('SELECT * FROM users WHERE email=?').get(String(email||'').toLowerCase());if(!u||!(await bcrypt.compare(String(password||''),u.password_hash)))return res.status(401).json({error:'Identifiants invalides'});res.cookie('session',tokenFor(u),{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',maxAge:7200000});audit({user:{sub:u.id},ip:req.ip},'LOGIN');res.json({user:{id:u.id,name:u.name,email:u.email,role:u.role}})});
app.post('/api/auth/logout',(req,res)=>{res.clearCookie('session');res.status(204).end()});
app.get('/api/auth/me',auth,(req,res)=>{const u=db.prepare('SELECT id,name,email,role FROM users WHERE id=?').get(req.user.sub);res.json({user:u})});

app.get('/api/catalog',(req,res)=>{const rows=db.prepare(`SELECT p.id,p.name,p.category,p.price_cents,p.stock,p.img,p.description,s.shop seller FROM products p JOIN sellers s ON s.id=p.seller_id WHERE p.active=1 AND s.status='approved' ORDER BY p.id DESC`).all();res.json({products:rows})});
app.post('/api/sellers',auth,role('customer'),(req,res)=>{const {shop,phone,category}=req.body||{};if(!shop||!phone||!category)return res.status(400).json({error:'Champs requis'});const r=db.prepare('INSERT INTO sellers(user_id,shop,phone,category) VALUES(?,?,?,?)').run(req.user.sub,shop,phone,category);audit(req,'SELLER_APPLICATION');res.status(201).json({id:r.lastInsertRowid,status:'pending'});});

app.get('/api/orders',auth,(req,res)=>{const orders=db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC').all(req.user.sub);res.json({orders})});
const orderSchema=z.object({items:z.array(z.object({productId:z.number().int().positive(),quantity:z.number().int().positive().max(100)})).min(1).max(50),paymentMethod:z.enum(['mobile_money','card','cash_on_delivery']),shipping:z.object({name:z.string().min(2).max(100),phone:z.string().min(8).max(30),address:z.string().min(5).max(300)})});
app.post('/api/orders',auth,role('customer','seller'),(req,res)=>{try{const d=orderSchema.parse(req.body);const tx=db.transaction(()=>{let total=0;const lines=[];for(const item of d.items){const p=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(item.productId);if(!p)throw new Error('Produit introuvable');if(p.stock<item.quantity)throw new Error('Stock insuffisant pour '+p.name);total+=p.price_cents*item.quantity;lines.push({p,q:item.quantity});}const code='CMD-'+Date.now().toString(36).toUpperCase();const o=db.prepare('INSERT INTO orders(code,user_id,total_cents,payment_method,shipping_name,shipping_phone,shipping_address) VALUES(?,?,?,?,?,?,?)').run(code,req.user.sub,total,d.paymentMethod,d.shipping.name,d.shipping.phone,d.shipping.address);const oi=db.prepare('INSERT INTO order_items(order_id,product_id,quantity,unit_price_cents) VALUES(?,?,?,?)');const dec=db.prepare('UPDATE products SET stock=stock-? WHERE id=?');lines.forEach(x=>{oi.run(o.lastInsertRowid,x.p.id,x.q,x.p.price_cents);dec.run(x.q,x.p.id)});audit(req,'CREATE_ORDER:'+code);return {id:o.lastInsertRowid,code,total_cents:total};});res.status(201).json(tx())}catch(e){res.status(400).json({error:e.message})}});

app.get('/api/seller/dashboard',auth,role('seller'),(req,res)=>{const s=db.prepare('SELECT * FROM sellers WHERE user_id=?').get(req.user.sub);if(!s)return res.status(404).json({error:'Boutique introuvable'});const products=db.prepare('SELECT * FROM products WHERE seller_id=?').all(s.id);const orders=db.prepare(`SELECT DISTINCT o.* FROM orders o JOIN order_items oi ON oi.order_id=o.id JOIN products p ON p.id=oi.product_id WHERE p.seller_id=? ORDER BY o.id DESC`).all(s.id);res.json({seller:s,products,orders})});
app.post('/api/seller/products',auth,role('seller'),(req,res)=>{const s=db.prepare('SELECT * FROM sellers WHERE user_id=? AND status=?').get(req.user.sub,'approved');if(!s)return res.status(403).json({error:'Boutique non approuvée'});const {name,category,priceCents,stock,img,description}=req.body||{};if(!name||!category||!Number.isInteger(priceCents)||priceCents<1||!Number.isInteger(stock)||stock<0)return res.status(400).json({error:'Produit invalide'});const r=db.prepare('INSERT INTO products(name,category,price_cents,stock,seller_id,img,description) VALUES(?,?,?,?,?,?,?)').run(name,category,priceCents,stock,s.id,img||'',description||'');audit(req,'CREATE_PRODUCT:'+r.lastInsertRowid);res.status(201).json({id:r.lastInsertRowid})});
app.patch('/api/seller/products/:id',auth,role('seller'),(req,res)=>{const s=db.prepare('SELECT * FROM sellers WHERE user_id=?').get(req.user.sub);const p=db.prepare('SELECT * FROM products WHERE id=? AND seller_id=?').get(req.params.id,s?.id);if(!p)return res.status(404).json({error:'Produit introuvable'});const stock=Number.isInteger(req.body.stock)?req.body.stock:p.stock;const price=Number.isInteger(req.body.priceCents)?req.body.priceCents:p.price_cents;db.prepare('UPDATE products SET stock=?,price_cents=? WHERE id=?').run(stock,price,p.id);audit(req,'UPDATE_PRODUCT:'+p.id);res.json({ok:true})});

app.get('/api/admin/dashboard',auth,role('admin'),(req,res)=>{const users=db.prepare('SELECT id,name,email,role,created_at FROM users ORDER BY id DESC').all();const sellers=db.prepare('SELECT s.*,u.name,u.email FROM sellers s JOIN users u ON u.id=s.user_id ORDER BY s.id DESC').all();const orders=db.prepare('SELECT * FROM orders ORDER BY id DESC').all();const stats={users:users.length,sellers:sellers.length,products:db.prepare('SELECT COUNT(*) c FROM products').get().c,orders:orders.length,revenue_cents:orders.reduce((a,o)=>a+o.total_cents,0)};res.json({stats,users,sellers,orders})});
app.patch('/api/admin/sellers/:id/status',auth,role('admin'),(req,res)=>{const status=z.enum(['approved','rejected','pending']).parse(req.body?.status);const s=db.prepare('SELECT * FROM sellers WHERE id=?').get(req.params.id);if(!s)return res.status(404).json({error:'Vendeur introuvable'});db.prepare('UPDATE sellers SET status=? WHERE id=?').run(status,s.id);if(status==='approved')db.prepare('UPDATE users SET role=? WHERE id=?').run('seller',s.user_id);audit(req,'SELLER_STATUS:'+s.id+':'+status);res.json({ok:true})});

app.use('/api',(_,res)=>res.status(404).json({error:'Route API introuvable'}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'../public/index.html')));
app.listen(PORT,()=>console.log(`MODE RDC running on http://localhost:${PORT}`));
