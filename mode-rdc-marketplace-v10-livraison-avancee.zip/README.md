# MODE RDC V10 — Livraison avancée

Marketplace Node.js/Express/SQLite en français, avec sécurité serveur et paiement côté backend.

## Nouveautés V10
- Historique des événements de livraison.
- Espace livreur `public/courier.html`.
- Jeton livreur aléatoire, stocké sous forme de hash en base, valable 7 jours.
- Révocation automatique de l'ancien accès lors d'une nouvelle affectation.
- Statuts livreur : colis récupéré, en livraison, échec.
- Code OTP à 6 chiffres pour confirmer la remise au client.
- Le passage à `delivered` par le livreur exige l'OTP.
- L'accès livreur est révoqué après livraison.
- Notifications client sur affectation et évolution de la livraison.
- Suivi client avec historique des événements.
- Coordonnées GPS facultatives sur les événements de livraison.
- Audit des actions de livraison.

## Lancer
1. Copier `.env.example` vers `.env`.
2. Définir un `JWT_SECRET` long et aléatoire.
3. `npm install`
4. `npm start`
5. Marketplace : `http://localhost:3000/`
6. Espace livreur : `http://localhost:3000/courier.html`

Les clés de paiement restent uniquement dans `.env` et ne doivent jamais être placées dans le frontend.
