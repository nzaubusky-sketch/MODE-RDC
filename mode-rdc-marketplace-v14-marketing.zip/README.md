# MODE RDC V13 — Catalogue professionnel

V13 ajoute un catalogue vendeur avancé :
- variantes produit avec SKU, prix, stock et attributs JSON ;
- plusieurs images par produit ;
- fiche produit enrichie côté catalogue public ;
- espace « Catalogue pro » vendeur ;
- modification détaillée des produits ;
- export CSV ;
- import CSV jusqu'à 2 Mo avec rapport succès/erreurs ;
- historique des imports ;
- contrôles d'accès vendeur côté serveur ;
- audit des opérations catalogue.

L'import CSV attend au minimum : `name,category,price_cents,stock`.
