# MODE RDC Marketplace

## Lancer
1. Installer Node.js 20+.
2. Copier `.env.example` vers `.env`.
3. Mettre une vraie valeur longue et aléatoire dans `JWT_SECRET`.
4. `npm install`
5. `npm start`
6. Ouvrir `http://localhost:3000`.

## Comptes de démonstration
- Admin: `admin@moderdc.local` / `ChangeMe!123`
- Vendeur: `seller@example.com` / `ChangeMe!123`

Change immédiatement ces mots de passe en environnement réel.

## Sécurité
- mots de passe hashés avec bcrypt
- session JWT en cookie HttpOnly
- Helmet
- rate limiting
- validation Zod
- RBAC côté API
- validation stock/prix côté serveur
- journal d'audit
- clés/secrets uniquement dans `.env`
- aucun secret de paiement dans le frontend

Le paiement réel doit être branché à un prestataire via son API et ses webhooks signés. Ne jamais traiter ou stocker directement les données sensibles de carte dans cette application.
